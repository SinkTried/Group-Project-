<?php
include 'dbconnection.php'; 

$doctors = []; 
$sql = "SELECT doc_id, name, specialty, days_available FROM doctor";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    $doctors = mysqli_fetch_all($result, MYSQLI_ASSOC);
}

$demo_times = [
    "09:00 AM - 10:00 AM",
    "10:00 AM - 11:00 AM",
    "11:00 AM - 12:00 PM",
    "01:00 PM - 02:00 PM",
    "02:00 PM - 03:00 PM"
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3c.css">
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <title>Doctors Appointment</title>
    
    <style>
        .container {
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
            color: #333;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .doctor-select {
            font-size: 16px;
            padding: 8px;
            margin-top: 10px;
            min-width: 300px;
            box-sizing: border-box; 
        }

        h2, h3 {
            color: #333;
        }
        td ul {
            margin: 0;
            padding-left: 20px;
        }
        input[type="submit"] {
            font-size: 16px;
            padding: 10px 15px;
            background-color: #0284c7;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 10px;
        }
        input[type="submit"]:hover {
            background-color: #0369a1;
        }
    </style>
</head>
<body>

    <div class="w-full">
        <img src="https://placehold.co/1200x300/e0f2fe/0284c7?text=Welcome+to+our+medical+center" 
             alt="Welcome to our medical center" 
             class="w-full h-auto object-cover">
    </div>

    <div style="padding-top: 0;" class="topnav">
        <a class="active" href="index.php">Home</a>
        <a href="YourAppointments.php">Your Appointments</a>
    </div>

    <div class="container">
    
        <div style="width: 100%;"> 

            <h2>Doctor Availability</h2>
            
            <table>
                <thead>
                    <tr>
                        <th>Doctor Name</th>
                        <th>Specialty</th>
                        <th>Days Available</th>
                        <th>Available Times (Demo)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($doctors)) {
                        foreach ($doctors as $doctor) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($doctor['name']) . "</td>";
                            echo "<td>" . htmlspecialchars($doctor['specialty']) . "</td>";
                            echo "<td>" . htmlspecialchars($doctor['days_available']) . "</td>";
                            
                            echo "<td>";
                            echo "<ul>";
                            foreach ($demo_times as $time) {
                                echo "<li>$time</li>";
                            }
                            echo "</ul>";
                            echo "</td>";
                            
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No doctors found in the database.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>

            <hr style="margin-top: 30px; margin-bottom: 30px;">

            <form action="AppointmentConfirmed.php" method="POST"> 
                
                <label for="doc_id_select">1. Choose a Doctor:</label><br>
                <select name="doc_id" id="doc_id_select" class="doctor-select" onchange="updateDays()">
                    <option value="">-- Please Select a Doctor --</option>
                    <?php
                    if (!empty($doctors)) {
                        foreach ($doctors as $doctor) {
                            $doc_name = htmlspecialchars($doctor['name']);
                            $doc_specialty = htmlspecialchars($doctor['specialty']);
                            $doc_days = htmlspecialchars($doctor['days_available']);
                            $doc_id = $doctor['doc_id'];
                            
                            echo "<option value=\"$doc_id\" data-days=\"$doc_days\">Dr. $doc_name ($doc_specialty)</option>";
                        }
                    }
                    ?>
                </select>
                <br><br>

                <label for="day_select">2. Choose a Day:</label><br>
                <select name="day" id="day_select" class="doctor-select" onchange="updateTimes()" disabled>
                    <option value="">-- Select a Doctor First --</option>
                </select>
                <br><br>

                <label for="time_select">3. Choose a Time:</label><br>
                <select name="time" id="time_select" class="doctor-select" disabled>
                    <option value="">-- Select a Day First --</option>
                </select>
                <br><br>

                <label for="full_name">4. Full Name:</label><br>
                <input type="text" id="full_name" name="full_name" class="doctor-select" required>
                <br><br>

                <label for="dob">5. Date of Birth:</label><br>
                <input type="date" id="dob" name="dob" class="doctor-select" required>
                <br><br>

                <label for="pin">6. 4-Digit PIN:</label><br>
                <input type="password" id="pin" name="pin" class="doctor-select" required maxlength="4" pattern="\d{4}" title="Please enter exactly 4 digits.">
                <br><br>


                <input type="submit" value="Book Appointment">
            </form>

        </div> </div> <script>
        const demoTimes = <?php echo json_encode($demo_times); ?>;
        const doctorSelect = document.getElementById('doc_id_select');
        const daySelect = document.getElementById('day_select');
        const timeSelect = document.getElementById('time_select');

        function updateDays() {
            const selectedOption = doctorSelect.options[doctorSelect.selectedIndex];
            const daysString = selectedOption.getAttribute('data-days');

            daySelect.innerHTML = '<option value="">-- Please Select a Day --</option>';
            timeSelect.innerHTML = '<option value="">-- Select a Day First --</option>';
            daySelect.disabled = true;
            timeSelect.disabled = true;

            if (daysString) {
                const daysArray = daysString.split(',').map(day => day.trim());
                
                daysArray.forEach(day => {
                    const option = document.createElement('option');
                    option.value = day;
                    option.textContent = day;
                    daySelect.appendChild(option);
                });

                daySelect.disabled = false;
            } else if (doctorSelect.value === "") {
                 daySelect.innerHTML = '<option value="">-- Select a Doctor First --</option>';
            }
        }

        function updateTimes() {
            timeSelect.innerHTML = '<option value="">-- Please Select a Time --</option>';
            timeSelect.disabled = true;

            if (daySelect.value !== "") {
                demoTimes.forEach(time => {
                    const option = document.createElement('option');
                    option.value = time;
                    option.textContent = time;
                    timeSelect.appendChild(option);
                });
                
                timeSelect.disabled = false;
            }
        }
    </script>

</body>
</html>