<?php

include 'dbconnection.php'; 

$appointment_details = null;
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $pin_submitted = $_POST['pin'];

    $stmt_user = mysqli_prepare($conn, "SELECT * FROM appntmnt WHERE full_name = ?");
    mysqli_stmt_bind_param($stmt_user, "s", $full_name);
    mysqli_stmt_execute($stmt_user);
    $result_user = mysqli_stmt_get_result($stmt_user);
    $user_appointment = mysqli_fetch_assoc($result_user);


    if ($user_appointment && password_verify($pin_submitted, $user_appointment['pin_hash'])) {
        
       
        $sql = "SELECT 
                    appntmnt.full_name, 
                    appntmnt.day_selected, 
                    appntmnt.time_selected,
                    doctor.name AS doc_name 
                FROM 
                    appntmnt
                JOIN 
                    doctor ON appntmnt.doc_id = doctor.doc_id
                WHERE 
                    appntmnt.appntmnt_id = ?";
        
        $stmt_details = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt_details, "i", $user_appointment['appntmnt_id']);
        mysqli_stmt_execute($stmt_details);
        $result_details = mysqli_stmt_get_result($stmt_details);
        $appointment_details = mysqli_fetch_assoc($result_details);

        if (!$appointment_details) {
            $error_message = "Could not find appointment details, even though user was verified. Please contact support.";
        }

    } else {
       
        $error_message = "Invalid name or PIN. Please try again.";
    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="styles.css">
    <meta charset="UTF-8">
    <title>Your Appointments</title>
    <style>
        /
        .topnav { background-color: #333; overflow: hidden; }
        .topnav a { float: left; color: #f2f2f2; text-align: center; padding: 14px 16px; text-decoration: none; font-size: 17px; }
        .topnav a:hover { background-color: #ddd; color: black; }
        .topnav a.active { background-color: #04AA6D; color: white; }
    </style>
</head>
<body>

<div class="w-full">
    <img src="https://placehold.co/1200x300/e0f2fe/0284c7?text=Welcome+to+Our+Medical+Center" 
         alt="Welcome to our medical center" 
         style="width:100%; height:auto; object-fit: cover;">
</div>

<div style="padding-top: 0;" class="topnav">
    <a href="index.php">Home</a>
    <a class="active" href="YourAppointments.php">Your Appointments</a>
</div>

<div class="w3-container" style="padding: 20px;">
    
    <h2>Check Your Appointment</h2>
    <p>Please enter your full name and PIN to view your appointment details.</p>

    <form action="YourAppointments.php" method="POST" class="w3-container" style="padding-top: 15px;">
        
        <label for="full_name"><b>Full Name</b></label>
        <input id="full_name" class="w3-input w3-border" type="text" name="full_name" required>

        <label for="pin" class="w3-margin-top"><b>PIN</b></label>
        <input id="pin" class="w3-input w3-border" type="password" name="pin" required>

        <button class="w3-btn w3-blue w3-margin-top" type="submit">Find Appointment</button>
    </form>

    <?php
    
    if (!empty($error_message)):
    ?>
        <div class="w3-panel w3-red w3-margin-top">
            <h3>Error!</h3>
            <p><?php echo htmlspecialchars($error_message); ?></p>
        </div>
    <?php
    
   
    elseif ($appointment_details):
    ?>
        <div class="w3-panel w3-green w3-margin-top">
            <h3>Appointment Found</h3>
        </div>
        
       <table class="w3-table w3-bordered w3-margin-top">
            <tr>
                <th>Patient Name</th>
                <th>Doctor</th>
                <th>Day</th>
                <th>Time</th>
            </tr>
            <tr>
                <td><?php echo htmlspecialchars($appointment_details['full_name']); ?></td>
                <td><?php echo htmlspecialchars($appointment_details['doc_name']); ?></td>
                <td><?php echo htmlspecialchars($appointment_details['day_selected']); ?></td>
                <td><?php echo htmlspecialchars($appointment_details['time_selected']); ?></td>
            </tr>
        </table>
    <?php
    endif;
    ?>

</div> </body>
</html>