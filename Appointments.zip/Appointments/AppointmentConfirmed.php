<?php
$message = "";
$message_type = "";


include 'dbconnection.php'; 


if (isset($_POST['doc_id'], $_POST['day'], $_POST['time'], $_POST['full_name'], $_POST['dob'], $_POST['pin'])) {
    
  
    $doc_id = $_POST['doc_id'];
    $day = $_POST['day'];
    $time = $_POST['time'];
    $full_name = $_POST['full_name'];
    $dob = $_POST['dob'];
    $pin = $_POST['pin'];

    if (empty($doc_id) || empty($day) || empty($time) || empty($full_name) || empty($dob) || empty($pin)) {
        $message = "Error: All fields are required.";
        $message_type = "error";
    } elseif (!preg_match('/^\d{4}$/', $pin)) {
        $message = "Error: PIN must be exactly 4 digits.";
        $message_type = "error";
    } else {
        
        
        $pin_hash = password_hash($pin, PASSWORD_DEFAULT);

     
        $sql = "INSERT INTO appntmnt (doc_id, full_name, dob, pin_hash, day_selected, time_selected) 
                VALUES (?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        
        if ($stmt === false) {
            $message = "Error preparing statement: " . $conn->error;
            $message_type = "error";
        } else {
            
            $stmt->bind_param("isssss", $doc_id, $full_name, $dob, $pin_hash, $day, $time);

           
            if ($stmt->execute()) {
                $message = "Success! Your appointment for $day at $time has been booked.";
                $message_type = "success";
            } else {
                $message = "Error: Could not book appointment. " . $stmt->error;
                $message_type = "error";
            }
            
            $stmt->close();
        }
    }
} else {
   
    $message = "Error: No form data submitted.";
    $message_type = "error";
}


$conn->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Booking Status</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3c.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        .container {
            padding: 20px;
        }

        .message-box {
            font-size: 18px;
            padding: 20px;
            border: 1px solid #ddd;
            background-color: #f4f4f4;
            border-radius: 5px;
            margin-top: 20px;
            text-align: center;
        }
        .message-box.success {
            background-color: #e6ffed;
            border-color: #04AA6D;
            color: #04AA6D;
        }
        .message-box.error {
            background-color: #ffe6e6;
            border-color: #c9302c;
            color: #c9302c;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            font-size: 16px;
            color: #0284c7;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>


    <div style="padding-top: 0;" class="topnav">
        <a href="index.php">Home</a>
        <a class="active" href="YourAppointments.php">Your Appointments</a>
    </div>

    <div class="container">
        <div style="width: 100%;"> 
            <h2>Appointment Booking Status</h2>
            
            <div class="message-box <?php echo $message_type; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>

            <a href="index.php" class="back-link">← Go Back to Appointments</a>
        </div>
    </div>

</body>
</html>